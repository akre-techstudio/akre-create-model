# A boiler plate to creating ML models

## Made for ML beginners

### by: AKRE Tech Studio
